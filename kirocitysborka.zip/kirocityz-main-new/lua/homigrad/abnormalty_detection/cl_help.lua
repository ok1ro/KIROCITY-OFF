-- if(SERVER)then
	-- PrintMessage(HUD_PRINTTALK, "Use 'stats_help' concommand to understand the stats")
-- end

ABNORMALTIESHELP = ABNORMALTIESHELP or {}
ABNORMALTIESHELP.Stats={
	[1] = {
		Name = "Введение",
		Desc = [[
		НЕ ИСПОЛЬЗУЙ ЭТО. ОСТАНОВИСЬ.
		ОСТАНОВИСЬ.
Похоже, ты нашёл нечто странное.
То, чем НИКОГДА не стоит пользоваться, пока не понимаешь, что делаешь. А ты не понимаешь.
Но если тебе хочется острых ощущений — что ж.
Эта книга — о проведении ритуалов и прочих скверных делах.

ВАЖНО: тауматургия работает только в режиме «Homicide» (хомисайд). В других режимах фразы не имеют силы.

Команды (писать в чат):
~ abnormalties_help — открыть эту книгу (команда в консоль).
~ /myabno — твой Баланс, запас Крови и Эквалайзеров.
~ /zoneabno — данные зоны, в которой ты стоишь.
~ /findphrase <значение> — подсказывает рабочую фразу (откроется позже).

1. ЗОНЫ
Тауматургическая зона возникает там, где ты произносишь тауматургическую фразу.
Зоны могут пересекаться и расти.
Внутри зоны проводятся ритуалы.
Чем сложнее произнесённая фраза, тем быстрее растёт зона.
Когда зона достаточно вырастет, придёт сообщение: «Зона выросла достаточно — началось накопление фраз и ритуалы». Только тогда зона «боевая».

2. ФРАЗЫ И БУКВЫ
Каждая буква алфавита что-то меняет в тауматургической таблице.
Таблица СЛУЧАЙНА и меняется при смене карты — заучить нельзя, её надо подбирать заново.
Тебе нужна фраза, в которой ровно ОДНО значение и нет «пустых» букв (нужно хотя бы около 6 разных значимых букв), иначе «в этих буквах нет смысла».
Значения, с которыми ты работаешь: ritual (ритуал), sacrifice (жертва), help (помощь), harm (вред), shield (щит).

3. КАК ПОДОБРАТЬ ПЕРВУЮ ФРАЗУ
Напиши набор букв в чат и повтори его несколько раз (в первый раз около 6 повторов — потом достаточно 2).
После этого тебе «подскажут» значения фразы, например:
- ноте бено мемо ммммт
~ Кажется, я к чему-то приближаюсь...
~ sacrifice — 2
~ ritual — 5
~ Но нужно убрать что-то лишнее...

Добавляй и убирай буквы, пока не останется ОДНО чистое значение. Тогда фраза готова.
Когда откроется знание insanity — можно просто писать /findphrase ritual, и тебе нашепчут готовую фразу.

4. РЕСУРСЫ
Кровь:
~ Чтобы набрать кровь, нужно, чтобы кто-то кровоточил ВНУТРИ зоны.
~ «Рисование» кровью (движение по полу) даёт чуть больше.
~ Радиус зоны поначалу мал, а растёт медленно — не лей кровь мимо неё.
~ Есть «Аномальная кровь» — она хранится в тебе, а не в зоне (добывается Тауматургической рукой).

Эквалайзеры:
~ Получай урон — они копятся на тебе.

5. РИТУАЛЫ
Продолжение — на следующих страницах.
]]
	},
	[2] = {
		Name = "Ритуалы. Часть 1 — Жизненная сила",
		Desc = [[Лечение и воскрешение.]]
	},
	[3] = {
		Name = "Лечение",
		Desc = [[
Нужно накопить В ЗОНЕ:
	sacrifice 10, help 20
	Кровь 2500
Как запустить:
	Быстро произнеси подряд 5 фраз, чередуя значения: help, sacrifice, help, sacrifice, help (по схеме «help 1, sacrifice 1 ...»). Уложись примерно в 10 секунд.
Что делает:
	Почти полностью лечит одного игрока, ближайшего к центру зоны.
	Читающий имеет приоритет в 2 раза выше остальных.
	Перед началом убери лишних игроков из зоны.
	Заметно снижает аномальные эффекты на 2 минуты (складывается при повторе).
	Душевные (ментальные) аномалии НЕ лечит.
	Сдвигает твой Баланс в минус (−20).
]]
	},
	[4] = {
		Name = "Воскрешение",
		Desc = [[
Нужно накопить В ЗОНЕ:
	sacrifice 50, help 30, ritual 10
	Кровь 3500
Как запустить:
	Быстро произнеси подряд 5 фраз значения ritual (по схеме «ritual 5», значение каждой не ниже 5). Уложись примерно в 10 секунд.
Что делает:
	Воскрешает одно тело, ближайшее к центру зоны.
	Перед началом убери лишние тела из зоны.
	Воскрешение иногда даёт непредвиденные последствия.
	У воскрешённого первое время сердце может случайно останавливаться.
	Сильно сдвигает твой Баланс в минус (−50).
]]
	},
	[5] = {
		Name = "Ритуалы. Часть 2 — Невидимость и взаимодействие",
		Desc = [[Невидимость, разоблачение и прочее.]]
	},
	[6] = {
		Name = "Невидимость (Cogito Evasion)",
		Desc = [[
Даже если меня видят — они не могут меня осознать.
Нужно накопить В ЗОНЕ:
	shield 10, help 20
	Эквалайзеры 50
Как запустить:
	Быстро произнеси подряд 5 фраз значения shield (по схеме «shield 10», значение каждой не ниже 10). Уложись примерно в 10 секунд.
Что делает:
	Даёт полную невидимость ближайшему к центру зоны до контакта с другим «носителем cogito» или на 45 секунд (не складывается).
	Читающий имеет приоритет в 2 раза выше остальных.
	Сдвигает твой Баланс в плюс (+20).
]]
	},
	[7] = {
		Name = "Вещание (Cogito Broadcast)",
		Desc = [[
Даже если я их вижу — я не могу их осознать, пока не использую их же приёмы.
Нужно накопить В ЗОНЕ:
	help 20, ritual 10
	Эквалайзеры 15
Как запустить:
	Быстро произнеси подряд 5 фраз значения help (по схеме «help 5», значение каждой не ниже 5). Уложись примерно в 10 секунд.
Что делает:
	Устанавливает контакт со всеми «носителями cogito».
	Снимает невидимость и подобные эффекты у всех.
	Читающий имеет приоритет в 2 раза выше остальных.
	Побочка: примерно 10 секунд всё, что ты говоришь, слышат все (не складывается).
	Сдвигает твой Баланс в плюс (+10).
]]
	},
	[8] = {
		Requirement = true,
		Name = "???",
		Desc = [[
		НЕ ИСПОЛЬЗУЙ ЭТО. ОСТАНОВИСЬ.
(остальной текст неразборчив)
(кажется, чтобы прочитать это, нужно что-то сделать)
]]
	},
	[9] = {
		Requirement = true,
		Name = "???",
		Desc = [[
(текст неразборчив)
(кажется, чтобы прочитать это, нужно проигнорировать все предупреждения)
]]
	},
	[10] = {
		Requirement = true,
		Name = "???",
		Desc = [[
(страница порвана и залита кровью, текст неразборчив)
(кажется, чтобы прочитать это, нужно сойти с ума)
]]
	},
	[11] = {
		Name = "Ритуалы. Часть 3 — Составные и сложные",
		Desc = [[Составные и тяжёлые ритуалы.]]
	},
	[12] = {
		Name = "Призыв Тауматургической руки",
		Desc = [[
Похоже, в ритуалах важнее всего ЧИСТОТА крови, а не её количество.
С помощью оружия, пропитанного магией, я смогу извлекать чистейшую кровь.
Нужно накопить В ЗОНЕ:
	ritual 20, harm 10, sacrifice 10
	Эквалайзеры 5
	Кровь 250
	Лишнее холодное оружие, положенное в зону
Как запустить:
	Положи холодное оружие в зону.
	Быстро произнеси подряд 5 фраз, чередуя значения: ritual, sacrifice, ritual, sacrifice, ritual (по схеме «ritual 2, sacrifice 2 ...», значение каждой не ниже 2). Уложись примерно в 10 секунд.
Что делает:
	Превращает положенное холодное оружие в Тауматургическую руку.
	Этим оружием можно вытягивать Аномальную кровь из себя или из любого человека.
	Сдвигает твой Баланс в минус (−10).
]]
	},
	[13] = {
		Requirement = true,
		Name = "???",
		Desc = [[
		ЭКСПЕРИМЕНТАЛЬНО, МОЖЕТ НЕ РАБОТАТЬ
(текст неразборчив)
(кажется, чтобы прочитать это, нужно зайти слишком далеко в плюс)
]]
	},
	[14] = {
		Requirement = true,
		Name = "???",
		Desc = [[
		ЭКСПЕРИМЕНТАЛЬНО, МОЖЕТ НЕ РАБОТАТЬ
(текст неразборчив)
(кажется, чтобы прочитать это, нужно зайти слишком далеко в минус)
]]
	},
	[15] = {
		Requirement = true,
		Name = "???",
		Desc = [[
(текст неразборчив)
(кажется, чтобы прочитать это, нужно зайти слишком далеко в плюс)
]]
	},
	[16] = {
		Requirement = true,
		Name = "???",
		Desc = [[
(текст неразборчив)
(кажется, чтобы прочитать это, нужно зайти слишком далеко в минус)
]]
	},
}

--; Добавить ритуалы:
--; Создание магической тыкалки

function ABNORMALTIESHELP:OpenStats(Recipe)
	Recipe=Recipe or 1
	if(!ABNORMALTIESHELP.Stats[Recipe])then
		if(Recipe <= 0)then
			Recipe = #ABNORMALTIESHELP.Stats
		else
			Recipe = 1
		end
	end
	if(IsValid(ABNORMALTIESHELP.Panel))then ABNORMALTIESHELP.Panel:Remove() end

	ABNORMALTIESHELP.Panel = vgui.Create("DFrame")
	local frame = ABNORMALTIESHELP.Panel
	local size={math.max(ScrW()/4,640),math.max(ScrH()/2.5,640)}

	frame:SetTitle("")
	frame:SetSize(size[1], 0)
	frame:SizeTo(size[1], size[2], 0.1)
	frame:SetPos((ScrW()-size[1])/2, (ScrH()-size[2]))
	frame:MoveTo((ScrW()-size[1])/2, (ScrH()-size[2])/2, 0.1)
	frame:MakePopup()
	frame:NoClipping(true)
	frame.Paint = function( sel, w, h )
		local fancyayy ={
			{ x = -10, y = -15 },
			{ x = w+50, y = -10 },
			{ x = w+4, y = h },
			{ x = -5, y = h+3 }
		}
		draw.NoTexture()
		surface.SetDrawColor( 150, 0, 0, 255 )
		surface.DrawPoly(fancyayy)
		local fancyayy1 ={
			{ x = 0, y = 1 },
			{ x = w+40, y = -4 },
			{ x = w, y = h-1 },
			{ x = 0, y = h }
		}
		draw.NoTexture()
		surface.SetDrawColor( 50, 50, 50, 255 )
		surface.DrawPoly(fancyayy1)
	end



	frame.Label = Label(ABNORMALTIESHELP.Stats[Recipe].Name, frame)
	frame.Label:SetFont("CloseCaption_Bold")
	frame.Label:Dock( TOP )
	frame.Label:SetSize(size[1],32)

	frame.Desc = vgui.Create("RichText",frame)
	frame.Desc:AppendText(ABNORMALTIESHELP.Stats[Recipe].Desc)
	function frame.Desc:PerformLayout()
		self:SetVerticalScrollbarEnabled(true)
		self:SetFontInternal("CloseCaption_Normal")
	end
	frame.Desc:Dock( TOP )
	frame.Desc:SetSize(size[1]-90,size[2]-100)

	frame.Prev = vgui.Create("DButton",frame)
	frame.Prev:SetText("<-- Назад")
	frame.Prev:SetPos(0, 0)
	frame.Prev:SetSize(50, 20)
	frame.Prev.DoClick = function()
		ABNORMALTIESHELP:OpenStats(Recipe - 1)
	end

	frame.PageNumberEntry = vgui.Create("DTextEntry",frame)
	frame.PageNumberEntry:SetNumeric(true)
	frame.PageNumberEntry:SetText(Recipe)
	frame.PageNumberEntry:SetPos(50, 0)
	frame.PageNumberEntry:SetSize(20, 20)
	frame.PageNumberEntry.OnEnter = function(sel)
		ABNORMALTIESHELP:OpenStats(tonumber(sel:GetValue()))
	end

	frame.Next = vgui.Create("DButton",frame)
	frame.Next:SetText("Вперёд -->")
	frame.Next:SetPos(70, 0)
	frame.Next:SetSize(50, 20)
	frame.Next.DoClick = function()
		ABNORMALTIESHELP:OpenStats(Recipe + 1)
	end

	if(ABNORMALTIESHELP.Stats[Recipe].Requirement)then
		net.Start("Abnormalties(SendOpenedPage)")
			net.WriteUInt(Recipe, 8)
		net.SendToServer()
	end
end

concommand.Add("abnormalties_help",function()
	ABNORMALTIESHELP:OpenStats()
end)

--\\Networking
net.Receive("Abnormalties(SendOpenedPage)", function(len, ply)
	local page = net.ReadUInt(8)
	local page_name = net.ReadString()
	local page_desc = net.ReadString()
	ABNORMALTIESHELP.Stats[page].Name = page_name
	ABNORMALTIESHELP.Stats[page].Desc = page_desc

	ABNORMALTIESHELP:OpenStats(page)
end)
--//
