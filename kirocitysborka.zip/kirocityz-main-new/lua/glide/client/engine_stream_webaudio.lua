-- Заглушка WebAudio-бэкенда Glide.
--
-- В этой сборке Glide (kirocityz-main-new) таблица Glide.WebAudio не создаётся,
-- но оригинальный engine_stream_webaudio.lua (из воркшоп-аддона Glide) всё равно
-- подключается через IncludeDir("glide/client/") и падает на строке:
--     local WebAudio = Glide.WebAudio   -- attempt to index local 'WebAudio' (a nil value)
--
-- Этот файл лежит в аддоне сервера и перекрывает воркшоп-версию, безопасно
-- создавая пустую таблицу. WebAudio-бэкенд в этой сборке не используется
-- (движок звука работает через Bass), поэтому методы не нужны.

Glide.WebAudio = Glide.WebAudio or {}
local WebAudio = Glide.WebAudio

-- Принудительно держим Bass-бэкенд, чтобы ничто не пыталось включить WebAudio.
if Glide.Config then
    Glide.Config.engineStreamBackend = 1
end

-- Безопасные пустышки на случай, если что-то всё же дёрнет методы WebAudio.
WebAudio.MAX_STREAMS = WebAudio.MAX_STREAMS or 32

function WebAudio:IsAvailable() return false end
function WebAudio:Enable() end
function WebAudio:Disable() end
function WebAudio:Restart() end
function WebAudio:Think() end
function WebAudio:SetDebugEnabled() end
function WebAudio:RequestStreamCreation() end
function WebAudio:RequestStreamDeletion() end
